package com.example.cs360project3;

public class User {
    protected String hashedPassword;
    private String email;

    //Getters and setters
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public String getHashedPassword() {
        return hashedPassword;
    }
    public void setHashedPassword(String hashedPassword) {
        this.hashedPassword = hashedPassword;
    }

    //constructor
    public User() {}
}
