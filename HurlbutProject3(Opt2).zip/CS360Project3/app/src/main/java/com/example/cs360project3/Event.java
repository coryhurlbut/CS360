package com.example.cs360project3;

public class Event {

    //Declare private variables
    private long id;
    private String who;
    private String what;
    private String when;
    private String where;
    private String why;
    private String whatElse;
    //Text true or false since I struggled working with converting to 1 and 0 in the database
    private String isActive;

    //Getters and setters
    public long getId() {
        return id;
    }
    public void setId(long id) {
        this.id = id;
    }
    public String isActive() {
        return isActive;
    }
    public void setActive(String active) {
        isActive = active;
    }
    public String getWho() {
        return who;
    }
    public void setWho(String who) {
        this.who = who;
    }
    public String getWhat() {
        return what;
    }
    public void setWhat(String what) {
        this.what = what;
    }
    public String getWhen() {
        return when;
    }
    public void setWhen(String when) {
        this.when = when;
    }
    public String getWhere() {
        return where;
    }
    public void setWhere(String where) {
        this.where = where;
    }
    public String getWhy() {
        return why;
    }
    public void setWhy(String why) {
        this.why = why;
    }
    public String getWhatElse() {
        return whatElse;
    }
    public void setWhatElse(String whatElse) {
        this.whatElse = whatElse;
    }

    //Constructors
    public Event() {
        this.who = "";
        this.what = "";
        this.when = "";
        this.where = "";
        this.why = "";
        this.whatElse = "";
        this.isActive = "false";
    }
}
