package com.example.cs360project3;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;


/**
 *  Main initial load class
 */
public class LoginActivity extends AppCompatActivity {

    //Declare fields and database handler
    private EditText email, password;
    private Button registerButton, loginButton;
    private DBHandler dbHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_activity);

        //Instantiate views and database
        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        registerButton = findViewById(R.id.registerButton);
        loginButton = findViewById(R.id.loginButton);
        dbHandler = new DBHandler(this);

        //Performs when register button is clicked
        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Get user inputs
                String userEmail = String.valueOf(email.getText());
                String userPassword = String.valueOf(password.getText());

                //If there are missing inputs, return and log
                if (userEmail.isEmpty() || userEmail == "null" || userPassword.isEmpty() || userPassword == "null") {
                    Log.wtf("Missing Data","Please enter all data");
                    return;
                }

                //If register was successful, pass this context to the main activity
                if (dbHandler.registerUser(userEmail, userPassword)) {
                    Intent intent = new Intent(LoginActivity.this, EventListActivity.class);
                    startActivity(intent);
                    finish();
                } else {
                    Log.wtf("Invalid email", "This email is already taken");
                }
            }
        });

        //Performs if login is clicked
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Get user inputs
                String userEmail = String.valueOf(email.getText());
                String userPassword = String.valueOf(password.getText());

                //If inputs are missing, return and log
                if (userEmail.isEmpty() || userEmail == "null" || userPassword.isEmpty() || userPassword == "null") {
                    Log.wtf("Missing Data","Please enter all data");
                    return;
                }

                //If login was successful, pass this context to the next activity
                if (dbHandler.loginUser(userEmail, userPassword)) {
                    Intent intent = new Intent(LoginActivity.this, EventListActivity.class);
                    startActivity(intent);
                    finish();
                } else {
                    Log.wtf("Invalid input", "Input is incorrect, please try again");
                }
            }
        });
    }
}