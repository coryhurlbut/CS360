package com.example.cs360project3;

import android.app.TimePickerDialog;
import android.content.Context;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.TimePicker;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Calendar;


public class EventAdapter extends RecyclerView.Adapter<EventAdapter.EventViewHolder> {
    //Declare state variables, and tools
    private ArrayList<Event> updatedEventList;
    private ArrayList<Event> eventList;
    private int expandedPosition = -1;//no expanded cards
    private EventAdapterListener listener;
    private Context activityContext;

    //Interface for interacting with the parent activity EventListActivity
    interface EventAdapterListener {
        void onEventSave(Event event, int position);
        void onEventDelete(long id, int position);
    }

    //Constructor
    public EventAdapter(Context context, ArrayList<Event> eventList) {
        activityContext = context;
        this.eventList = new ArrayList<>(eventList);
        this.updatedEventList = new ArrayList<>(eventList);
    }

    @NonNull
    @Override
    public EventViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.event_card, parent, false);
        return new EventViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull EventAdapter.EventViewHolder holder, int position) {
        //building each eventCardView. Triggered by each reload
        Event event = eventList.get(position);
        holder.eventWhoTextView.setText(event.getWho());
        holder.eventWhatTextView.setText(event.getWhat());
        holder.eventWhenTextView.setText(event.getWhen());
        holder.eventWhereTextView.setText(event.getWhere());
        holder.eventWhyTextView.setText(event.getWhy());
        holder.eventWhatElseTextView.setText(event.getWhatElse());
        holder.eventIsActiveSwitch.setChecked(Boolean.parseBoolean(event.isActive()));
        holder.eventWhenSmallTextView.setText(event.getWhen());
        holder.eventWhatSmallTextView.setText(event.getWhat());

        //Controls the expanding cardviews. one at a time
        final boolean isExpanded = position == expandedPosition;
        holder.smallLayout.setVisibility(!isExpanded ? View.VISIBLE : View.GONE);
        holder.expandedLayout.setVisibility(isExpanded ? View.VISIBLE : View.GONE);

        holder.smallLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                expandedPosition = isExpanded ? -1 : holder.getAdapterPosition();
                updatedEventList = eventList;
                notifyDataSetChanged();
            }
        });
        holder.expandedLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                expandedPosition = isExpanded ? -1 : holder.getAdapterPosition();
                updatedEventList = eventList;
                notifyDataSetChanged();
            }
        });
        holder.eventSaveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (listener != null) {
                    int position = holder.getAdapterPosition();
                    listener.onEventSave(updatedEventList.get(position), position);
                }
            }
        });
        holder.eventDeleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (listener != null) {
                    int position = holder.getAdapterPosition();
                    listener.onEventDelete(event.getId(), position);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return eventList.size();
    }

    public void setEventAdapterListener(EventAdapterListener listener) {
        this.listener = listener;
    }

    public void updateData(ArrayList<Event> newEventList) {
        this.eventList.clear();
        this.eventList = new ArrayList<>(newEventList);
        this.updatedEventList = new ArrayList<>(newEventList);
        notifyDataSetChanged();
    }

    //Subclass viewholder
    public class EventViewHolder extends RecyclerView.ViewHolder {
        EditText eventWhoTextView,
                eventWhatTextView,
                eventWhereTextView,
                eventWhyTextView,
                eventWhatElseTextView;
        TextView eventWhenTextView,
                eventWhenSmallTextView,
                eventWhatSmallTextView;
        Switch eventIsActiveSwitch;
        ConstraintLayout smallLayout,
                expandedLayout;
        ImageButton eventSaveButton,
                eventDeleteButton,
                eventEditWhenButton;

        //Constructor
        public EventViewHolder(View eventCardView) {
            super(eventCardView);
            //initialize eventcard items
            smallLayout = eventCardView.findViewById(R.id.smallLayout);
            expandedLayout = eventCardView.findViewById(R.id.expandedLayout);
            eventWhoTextView = eventCardView.findViewById(R.id.editWhoText);
            eventWhatTextView = eventCardView.findViewById(R.id.editWhatText);
            eventWhenTextView = eventCardView.findViewById(R.id.editWhenText);
            eventWhereTextView = eventCardView.findViewById(R.id.editWhereText);
            eventWhyTextView = eventCardView.findViewById(R.id.editWhyText);
            eventWhatElseTextView = eventCardView.findViewById(R.id.editWhatElseText);
            eventIsActiveSwitch = eventCardView.findViewById(R.id.isActiveSwitch);
            eventWhenSmallTextView = eventCardView.findViewById(R.id.whenSmall);
            eventWhatSmallTextView = eventCardView.findViewById(R.id.whatSmall);
            eventSaveButton = eventCardView.findViewById(R.id.saveButton);
            eventDeleteButton = eventCardView.findViewById(R.id.deleteButton);
            eventEditWhenButton = eventCardView.findViewById(R.id.editWhenButton);

            eventWhoTextView.addTextChangedListener((new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {                }
                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    int position = getAdapterPosition();
                    if (position != -1) {
                        updatedEventList.get(position).setWho(s.toString());
                    }
                }
                @Override
                public void afterTextChanged(Editable s) {                }
            }));
            eventWhatTextView.addTextChangedListener((new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {                }
                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    int position = getAdapterPosition();
                    if (position != -1) {
                        updatedEventList.get(position).setWhat(s.toString());
                    }
                }
                @Override
                public void afterTextChanged(Editable s) {                }
            }));
            eventWhenTextView.addTextChangedListener((new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {                }
                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    int position = getAdapterPosition();
                    if (position != -1) {
                        updatedEventList.get(position).setWhen(s.toString());
                    }
                }
                @Override
                public void afterTextChanged(Editable s) {                }
            }));
            eventEditWhenButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int position = getAdapterPosition();
                    if (position != -1) {
                        showTimePickerDialog(activityContext);
                    }
                }
            });
            eventWhereTextView.addTextChangedListener((new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {                }
                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    int position = getAdapterPosition();
                    if (position != -1) {
                        updatedEventList.get(position).setWhere(s.toString());
                    }
                }
                @Override
                public void afterTextChanged(Editable s) {                }
            }));
            eventWhyTextView.addTextChangedListener((new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {                }
                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    int position = getAdapterPosition();
                    if (position != -1) {
                        updatedEventList.get(position).setWhy(s.toString());
                    }
                }
                @Override
                public void afterTextChanged(Editable s) {                }
            }));
            eventWhatElseTextView.addTextChangedListener((new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {                }
                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    int position = getAdapterPosition();
                    if (position != -1) {
                        updatedEventList.get(position).setWhatElse(s.toString());
                    }
                }
                @Override
                public void afterTextChanged(Editable s) {                }
            }));
            eventIsActiveSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
                int position = getAdapterPosition();
                if (position != -1) {
                    updatedEventList.get(position).setActive(String.valueOf(isChecked));
                }
            });
        }

        private void showTimePickerDialog(Context context) {
            Calendar calendar = Calendar.getInstance();
            int hour = calendar.get(Calendar.HOUR_OF_DAY);
            int minute = calendar.get(Calendar.MINUTE);

            TimePickerDialog timePickerDialog = new TimePickerDialog(context, new TimePickerDialog.OnTimeSetListener() {
                @Override
                public void onTimeSet(TimePicker view, int hour, int minute) {
                    String newTime = String.format(
                            "%02d:%02d %s",
                            hour == 0 || hour == 12 ? 12 : hour % 12, minute,
                            hour < 12 ? "AM" : "PM"
                    );
                    eventWhenTextView.setText(newTime);
                }
            }, hour, minute, false);

            timePickerDialog.show();
        }
    }
}
