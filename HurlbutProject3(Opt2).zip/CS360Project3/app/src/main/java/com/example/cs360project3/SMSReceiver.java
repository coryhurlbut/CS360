package com.example.cs360project3;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.telephony.SmsManager;

public class SMSReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        sendTextMessage(context, "Go to sleep!");
    }

    private void sendTextMessage(Context context, String message) {
        SmsManager smsManager = SmsManager.getDefault();
        smsManager.sendTextMessage(
                "+12343212342",
                null,
                message,
                null,
                null);
    }
}
