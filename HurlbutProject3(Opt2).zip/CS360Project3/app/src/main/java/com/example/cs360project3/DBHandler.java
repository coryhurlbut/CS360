package com.example.cs360project3;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class DBHandler extends SQLiteOpenHelper {

    //users table constants
    private static final String DB_NAME = "eventAppDB";
    private static final int DB_VERSION = 1;
    private static final String TABLE_USERS = "users";
    private static final String ID_COL = "id";
    private static final String EMAIL_COL = "email";
    private static final String PASSWORD_COL = "password";

    //events table constants
    private static final String TABLE_EVENTS = "events";
    private static final String WHO_COL = "who";
    private static final String WHAT_COL = "what";
    private static final String WHEN_COL = "\"when\"";
    private static final String WHERE_COL = "\"where\"";
    private static final String WHY_COL = "why";
    private static final String WHAT_ELSE_COL = "what_else";
    private static final String IS_ACTIVE_COL = "is_active";



    public DBHandler(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        //SQL for creating the users table
        String queryUsers = "CREATE TABLE " + TABLE_USERS + " ("
                + ID_COL + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + EMAIL_COL + " TEXT, "
                + PASSWORD_COL + " TEXT)";
        db.execSQL(queryUsers);

        //SQL for creating the events table
        String queryEvents = "CREATE TABLE " + TABLE_EVENTS + " ("
                + ID_COL + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + WHO_COL + " TEXT, "
                + WHAT_COL + " TEXT, "
                + WHEN_COL + " TEXT, "
                + WHERE_COL + " TEXT, "
                + WHY_COL + " TEXT, "
                + WHAT_ELSE_COL + " TEXT, "
                + IS_ACTIVE_COL + " TEXT)";
        db.execSQL(queryEvents);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // this method is called to check if the table exists already.
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_EVENTS);
        onCreate(db);
    }

    public User getUserByEmail(String userEmail) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM users WHERE email = ?";
        User user = null;
        if (userEmail != null) {
            Cursor cursor = db.rawQuery(query, new String[]{userEmail});
            if (cursor.moveToFirst()) {
                user = new User();
                user.setEmail(cursor.getString(cursor.getColumnIndexOrThrow(EMAIL_COL)));
                user.setHashedPassword(cursor.getString(cursor.getColumnIndexOrThrow(PASSWORD_COL)));
            }
            db.close();
        }
        return user;
    }

    public boolean registerUser(String userEmail, String userPassword) {
        //If there is no user with that email, register user
        if (getUserByEmail(userEmail) == null) {
            SQLiteDatabase db = this.getWritableDatabase();

            ContentValues values = new ContentValues();
            values.put(EMAIL_COL, userEmail);
            values.put(PASSWORD_COL, userPassword.hashCode());

            db.insert(TABLE_USERS, null, values);
            db.close();

            return loginUser(userEmail, userPassword);
        } else {
            return false;
        }
    }

    public boolean loginUser(String userEmail, String userPassword) {
        //If there is a user with that email and the password hashes match, login user
        User user = getUserByEmail(userEmail);
        if (user == null) return false;
        if (String.valueOf(userPassword.hashCode()).equals(user.getHashedPassword())) {
            return true;
        } else {
            return false;
        }
    }

    public long addEvent(Event event) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(WHO_COL, event.getWho());
        values.put(WHAT_COL, event.getWhat());
        values.put(WHEN_COL, event.getWhen());
        values.put(WHERE_COL, event.getWhere());
        values.put(WHY_COL, event.getWhy());
        values.put(WHAT_ELSE_COL, event.getWhatElse());
        values.put(IS_ACTIVE_COL, event.isActive());

        long id = db.insert(TABLE_EVENTS, null, values);
        db.close();
        event.setId(id);

        return id;
    }

    public ArrayList<Event> getAllEvents() {
        ArrayList<Event> eventList = new ArrayList<>();
        String selectQuery = "SELECT * FROM " + TABLE_EVENTS;
        SQLiteDatabase db = this.getWritableDatabase();

        Cursor cursor = db.rawQuery(selectQuery, null);
        if (cursor.moveToFirst()) {
            do {
                Event event = new Event();
                event.setId(cursor.getLong(cursor.getColumnIndexOrThrow(ID_COL)));
                event.setWho(cursor.getString(cursor.getColumnIndexOrThrow(WHO_COL)));
                event.setWhat(cursor.getString(cursor.getColumnIndexOrThrow(WHAT_COL)));
                event.setWhen(cursor.getString(cursor.getColumnIndexOrThrow("when")));
                event.setWhere(cursor.getString(cursor.getColumnIndexOrThrow("where")));
                event.setWhy(cursor.getString(cursor.getColumnIndexOrThrow(WHY_COL)));
                event.setWhatElse(cursor.getString(cursor.getColumnIndexOrThrow(WHAT_ELSE_COL)));
                event.setActive(cursor.getString(cursor.getColumnIndexOrThrow(IS_ACTIVE_COL)));
                eventList.add(event);
            } while (cursor.moveToNext());
        }
        cursor.close();

        return eventList;
    }

    public int updateEvent(Event event) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(WHO_COL, event.getWho());
        values.put(WHAT_COL, event.getWhat());
        values.put(WHEN_COL, event.getWhen());
        values.put(WHERE_COL, event.getWhere());
        values.put(WHY_COL, event.getWhy());
        values.put(WHAT_ELSE_COL, event.getWhatElse());
        values.put(IS_ACTIVE_COL, event.isActive());

        return db.update(TABLE_EVENTS, values, ID_COL + " = ?",
                new String[]{String.valueOf(event.getId())});
    }

    public void deleteEvent(long id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_EVENTS, ID_COL + " = ?",
                new String[]{String.valueOf(id)});
        db.close();
    }
}
