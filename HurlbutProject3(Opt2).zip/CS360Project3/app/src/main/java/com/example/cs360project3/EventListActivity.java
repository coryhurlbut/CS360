package com.example.cs360project3;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.Calendar;

public class EventListActivity extends AppCompatActivity implements EventAdapter.EventAdapterListener {

    //Declare views
    private RecyclerView recyclerView;
    private FloatingActionButton addEventFAB;

    //Declare classes and state
    private EventAdapter eventAdapter;
    private ArrayList<Event> eventList;
    private DBHandler dbHandler;

    //Declare tools
    private AlarmManager alarmManager;
    private PendingIntent pendingIntent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.events_list_activity);

        //instantiate our objects and database
        addEventFAB = findViewById(R.id.addEventFAB);
        recyclerView = findViewById(R.id.recycler_view);
        dbHandler = new DBHandler(this);

        //call for SMS permissions if they are not already accepted on the current device.
        requestPermission();

        //Set up our alarm manager that will trigger our SMSs
        alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        Intent alarmIntent = new Intent(getApplicationContext(), SMSReceiver.class);
        pendingIntent =
                PendingIntent.getBroadcast(getApplicationContext(), 0, alarmIntent, PendingIntent.FLAG_IMMUTABLE);


        //populate eventCardList through the adapter
        eventList = dbHandler.getAllEvents();
        eventAdapter = new EventAdapter(this, eventList);
        eventAdapter.setEventAdapterListener(this);

        // attach the adapter to the recyclerview
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(eventAdapter);

        //Triggered when the add event button is clicked
        addEventFAB.setOnClickListener(v -> {
            //adds new event to the database, updates this eventList, then refreshes the adapter's eventlist.
            Event newEvent = new Event();
            dbHandler.addEvent(newEvent);
            this.eventList = dbHandler.getAllEvents();
            eventAdapter.updateData(this.eventList);
        });
    }

    public void onEventSave(Event event, int position) {
        //updates the database with the new event, refreshes this eventlist, ensures all alarms are properly set, then refreshes adapter eventlist
        dbHandler.updateEvent(event);
        this.eventList = dbHandler.getAllEvents();
        updateAlarms();
        eventAdapter.updateData(this.eventList);
    }

    public void onEventDelete(long id, int position) {
        //updates the database without the event, refreshes this eventlist, ensures all alarms are properly set, then refreshes adapter eventlist
        dbHandler.deleteEvent(id);
        this.eventList = dbHandler.getAllEvents();
        updateAlarms();
        eventAdapter.updateData(this.eventList);
    }

    private void requestPermission() {
        String permissionStr = "android.permission.SEND_SMS";

        //If permission was not granted, request permission
        if (ContextCompat.checkSelfPermission(this, permissionStr) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{permissionStr}, 1);
        }
    }

    //returns the milliseconds of the event given
    public long getMillis(String eventWhen) {
        //parses hour and minute from the text (%02d:%02d %s)
        int hour = Integer.parseInt(eventWhen.substring(0, eventWhen.indexOf(":")));
        int minute = Integer.parseInt(eventWhen.substring(3, eventWhen.indexOf(" ")));

        //adds the chosen time to the current day since # of milliseconds from 1970 is a large #
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, hour);
        calendar.set(Calendar.MINUTE, minute);

        return calendar.getTimeInMillis();
    }

    public void updateAlarms() {
        for (Event event : eventList) {
            //if it is not an empty field(New event) and is set active
            if (event.getWhen() != "" && event.isActive() == "true") {
                scheduleEventTimer(event);
            } else {
                cancelEventTimer(event);
            }
        }
    }

    public void scheduleEventTimer(Event event) {
        alarmManager.set(AlarmManager.RTC_WAKEUP, getMillis(event.getWhen()), pendingIntent);
    }

    public void cancelEventTimer(Event event) {
        if (alarmManager != null) {
            alarmManager.cancel(pendingIntent);
        }
    }
}
